import bpy, os, re, sys

def prepare(obj):
    print("Preparing: " + obj.name)
    pass